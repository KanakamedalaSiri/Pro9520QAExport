
const path = require('path');
const { writeFileSync, existsSync, mkdirSync } = require('fs');
const { newResult } = require('./utils');
const { app, ipcMain } = require('electron');
const ioBootstrap = require('./voltmxIOApiBootstrap');
const fs = require('fs');

function isFile(targetPath) {
    return fs.lstatSync(targetPath).isFile();
} 

function isDirectory(targetPath) {
    return fs.lstatSync(targetPath).isDirectory();
} 

function volmxIOHandlers(context) {
    
    ipcMain.on(ioBootstrap.channel_io_bootstrap,  (event, args) => {
        event.returnValue = ioBootstrap;
    })

    ipcMain.on(ioBootstrap.channel_filesystem_getDataDirectory, (event, args) => {
        console.debug("on getDataDirectory");
        const result = newResult();
        // result.value = path.join(__dirname, 'data');
        result.value = path.join(app.getPath('userData'), 'data');
        event.returnValue = result;
    })

    ipcMain.on(ioBootstrap.channel_file_createFile, (event, filePath, data) => {
        console.debug("handle createFile");
        this.filePath = filePath;
        const result = newResult();
        let res = true;
        try{
            if (filePath) {
                const dName = path.dirname(filePath);
                if (dName && !existsSync(dName)) {
                    mkdirSync(dName);
                }
            }
            writeFileSync(filePath, data, 'utf8');
        } catch (e) {
            console.log(e);
            result.error = e;
            res = false;
        }
        result.value = res;
        event.returnValue = result;
    })

    ipcMain.on(ioBootstrap.channel_file_copyTo, (event, sourcePath, targetPath, newName) => {        
        console.debug(`on ${ioBootstrap.channel_file_copyTo}`);
        const result = newResult();
        try {
            if (fs.existsSync(sourcePath)) {
                let nName = path.basename(sourcePath);
                if (newName) {
                    const dName = path.dirname(newName);
                    // If the newName has a path, don't continue
                    if (dName && dName !== '.') {
                        result.error = new Error("File or directory cannot be copied because the new name includes a path");
                        result.value = false;
                        event.returnValue = result;
                        return;
                    } 
                    nName = newName;
                }
                // Create the target path if it doesn't exist, otherwise rename will fail
                if (!existsSync(targetPath)) {
                    mkdirSync(targetPath);
                }
                fs.copyFileSync(sourcePath, path.join(targetPath, nName));
                result.value = true;
            } else {
                result.error = new Error(`${sourcePath} does not exist.`);
                result.value = false;
            }
        } catch (error) {
            result.error = error;
            result.value = false;
        }
        event.returnValue = result;
    })

    ipcMain.on(ioBootstrap.channel_file_createDirectory, (event, dirPath) => {        
        console.debug(`on ${ioBootstrap.channel_file_createDirectory}`);
        const result = newResult();
        try {
            mkdirSync(dirPath, { recursive: true });
            result.value = true;
        } catch (err) {
            result.error = err;
            result.value = false;
        }
        event.returnValue = result;
    })

    ipcMain.on(ioBootstrap.channel_file_fileExists, (event, filePath) => {        
        console.debug(`on ${ioBootstrap.channel_file_fileExists}`);
        const result = newResult();
        try {
            result.value = fs.existsSync(filePath);
        } catch (err) {
            result.error = err;
            result.value = false;
        }
        event.returnValue = result;
    })

    ipcMain.on(ioBootstrap.channel_file_getFileList, (event, dirPath) => {        
        console.debug(`on ${ioBootstrap.channel_file_getFileList}`);
        const result = newResult();
        try {
            if (fs.existsSync(dirPath) && isDirectory(dirPath)) {
                result.value = fs.readdirSync(dirPath);
            } else {
                result.value = null;
            }
        } catch (err) {
            result.error = err;
        }
        event.returnValue = result;
    })

    ipcMain.on(ioBootstrap.channel_file_isDirectory, (event, targetPath) => {        
        console.debug(`on ${ioBootstrap.channel_file_isDirectory}`);
        const result = newResult();
        try {
            result.value = isDirectory(targetPath);
        } catch (err) {
            result.error = err;
            result.value = false;
        }
        event.returnValue = result;
    })

    ipcMain.on(ioBootstrap.channel_file_isFile, (event, targetPath) => {        
        console.debug(`on ${ioBootstrap.channel_file_isFile}`);
        const result = newResult();
        try {
            result.value = isFile(targetPath); 
        } catch (err) {
            result.value = false;
            result.error = err;
        }
        event.returnValue = result;
    })

    ipcMain.on(ioBootstrap.channel_file_moveTo, (event, sourcePath, targetPath, newName) => {        
        console.debug(`on ${ioBootstrap.channel_file_moveTo}`);
        const result = newResult();
            try {
                if (fs.existsSync(sourcePath)) {
                    let nName = path.basename(sourcePath);
                    if (newName) {
                        const dName = path.dirname(newName);
                        // If the newName has a path, don't continue
                        if (dName && dName !== '.') {
                            result.error = new Error("File or directory cannot be moved because the new name has a path");
                            result.value = false;
                            event.returnValue = result;
                            return;
                        } 
                        nName = newName;
                    }
                    // Create the target path if it doesn't exist, otherwise rename will fail
                    if (!existsSync(targetPath)) {
                        mkdirSync(targetPath);
                    }
                    fs.renameSync(sourcePath, path.join(targetPath, nName));
                    result.value = true;
                } else {
                    result.error = new Error(`${sourcePath} does not exist.`);
                    result.value = false;
                }
            } catch (error) {
                result.error = error;
                result.value = false;
            }

            event.returnValue = result;
    })

    ipcMain.on(ioBootstrap.channel_file_read, (event, filePath) => {        
        console.debug(`on ${ioBootstrap.channel_file_read}`);
        const result = newResult();
        
        // return new Promise(async (resolve) => {
        //     try {
        //         await fs.readFile(filePath, (err, data) => {
        //             if (err) {
        //                 result.error = err;
        //                 result.value = undefined;
        //             } else {
        //                 result.value = data;
        //             }
        //         });
        //     } catch (error) {
        //         result.error = error;
        //         result.value = undefined;
        //     }
        //     resolve(result);
        // });
        try {
            if (fs.existsSync(filePath) && isFile(filePath)) {
                result.value = fs.readFileSync(filePath);
            } else {
                result.value = null;
            }
        } catch (error) {
            result.error = error;
            result.value = undefined;
        }
        event.returnValue = result;

    })

    ipcMain.on(ioBootstrap.channel_file_readAsText, (event, filePath) => {        
        console.debug(`on ${ioBootstrap.channel_file_readAsText}`);
        const encoding = 'utf8';
        const result = newResult();
        try {
            // fs.readFile(filePath, encoding, (err, data) => {
            //     if (err) {
            //         result.error = err;
            //         result.value = undefined;
            //     } else {
            //         result.value = data;
            //     }
            // });
            if (fs.existsSync(filePath) && isFile(filePath)) {
                result.value = fs.readFileSync(filePath, encoding);
            } else {
                result.value = null;
            }
        } catch (error) {
            result.error = error;
            result.value = undefined;
        }
        event.returnValue = result;
    });

    ipcMain.on(ioBootstrap.channel_file_remove, (event, targetPath, deleteRecursive) => {        
        console.debug(`on ${ioBootstrap.channel_file_remove}`);
        const result = newResult();
        try {
            if (isFile(targetPath)) {
                fs.unlinkSync(targetPath);
                result.value = true;
            } else if (isDirectory(targetPath)) {
                const dRecursive = deleteRecursive === true;
                fs.rmdirSync(targetPath, { recursive: dRecursive });
                result.value = true;
            } else {
                result.value = false;
                result.error = new Error(`${targetPath} is not a file or directory and cannot be removed.`);
            }
        } catch (err) {
            console.log(err);
            result.error = err;
            result.value = false;
        }
        event.returnValue = result;
    })

    ipcMain.on(ioBootstrap.channel_file_rename, (event, filePath, newName) => {        
        console.debug(`on ${ioBootstrap.channel_file_rename}`);
        const result = newResult();
        try {
            const originalPath = path.dirname(filePath);
            const targetPath = path.dirname(newName);
            if (targetPath && targetPath !== '.' && targetPath !== originalPath) {
                result.error = new Error("Cannot rename because the target is a different path than the original");
                result.value = false;
            } else {
                const nName = path.basename(newName);
                const targetName = originalPath && originalPath !== '.' ? path.join(originalPath, nName) : nName;
                fs.renameSync(filePath, targetName);
                result.value = true;
            }
        } catch (err) {
            result.error = err;
            result.value = false;
        }
        event.returnValue = result;
    })

    ipcMain.on(ioBootstrap.channel_file_write, (event, filePath, data, append) => {
        console.debug(`on ${ioBootstrap.channel_file_write}`);
        const result = newResult();
        let res = false;
        try {
            if (filePath) {
                const dName = path.dirname(filePath);
                if (dName && !existsSync(dName)) {
                    mkdirSync(dName);
                }
            }
            const options = {
                encoding: 'utf8'
            }
            if (append === true) {
                options.flag = 'a'
            }
            let writeData = data;
            if (Array.isArray(writeData)) {
                writeData = Buffer.from(writeData);
            }
            writeFileSync(filePath, writeData, options);
            res = true;
        } catch (e) {
            console.log(e);
            result.error = e;
        }
        result.value = res;
        event.returnValue = result;
    })
}

function loadAPIHandlers(context)  {
    this.volmxIOHandlers(context);
}
module.exports = {volmxIOHandlers, loadAPIHandlers};


