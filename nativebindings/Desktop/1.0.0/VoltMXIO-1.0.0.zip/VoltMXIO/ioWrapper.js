// Replace the voltmx namespace.
// This file cannot reference Node or other modules
if (window.voltmxio?.io) {
    function FileWrapper(filePath) {
        this.filePath = filePath;
        this.createFile = function() {
            return new window.voltmxio.io.File(filePath).createFile();
        }
        this.copyTo = function(targetPath, newName) {
            const results = new window.voltmxio.io.File(filePath).copyTo(targetPath, newName);
            return results;
        }

        this.createDirectory = function() {
            return new window.voltmxio.io.File(filePath).createDirectory();
        }

        this.exists = function () {
            return new window.voltmxio.io.File(filePath).exists();
        }

        this.getFileList = function() {
            const results = new window.voltmxio.io.File(filePath).getFileList();
            let fList;
            if (results) {
                fList = new voltmx.io.FileList(results);
            }
            console.log("FileList: " + fList);
            return fList;
        }

        this.isDirectory = function() {
            return new window.voltmxio.io.File(filePath).isDirectory();
        }

        this.isFile = function() {
            return new window.voltmxio.io.File(filePath).isFile();
        }

        this.moveTo = function(targetPath, newName) {
            const results = new window.voltmxio.io.File(filePath).moveTo(targetPath, newName);
            return results;
        }

        this.read = function() {
            return new window.voltmxio.io.File(filePath).read();
        }

        this.readAsText = function() {
            return new window.voltmxio.io.File(filePath).readAsText();
        }

        this.remove = function(deleteRecursive) {
            return new window.voltmxio.io.File(filePath).remove(deleteRecursive);
        }

        this.rename = function(newName) {
            return new window.voltmxio.io.File(filePath).rename(newName);
        }

        this.write = function(data, append) {
            return new window.voltmxio.io.File(filePath).write(data, append);
        }
    }

    if (window.voltmx) {
        if (!Object.getOwnPropertyDescriptor(window.voltmx, 'io')) {
            Object.defineProperty(window.voltmx, 'io', {configurable: true, enumerable: true, writable: true, value: {}});
        }

        // Apis replaced (from preload.js)

        // window.voltmx.io.File = window.voltmxio.io.File;
        window.voltmx.io.File = FileWrapper;

        if (window.voltmxio.io.FileSystem) {
            if (!Object.getOwnPropertyDescriptor(window.voltmx.io, 'FileSystem')) {
                Object.defineProperty(window.voltmx.io, 'FileSystem', {configurable: true, enumerable: true, writable: true, value: {}});
            }
            // window.voltmx.io.FileSystem = window.voltmxio.io.FileSystem;
            window.voltmx.io.FileSystem.getDataDirectoryPath = window.voltmxio.io.FileSystem.getDataDirectory;
        }
    } else {
        console.log("Could not load ioWrapper because window.voltmx does not exist.")
    }

} else {
    console.log("Could not load ioWrapper because voltmxio.io does not exist.  Check for preload.js errors.")
}
