module.exports = {
    channel_io_bootstrap: "com.hcl.voltmx.ioBootstrap",

    // IO api channels
    channel_filesystem_getDataDirectory: "com.hcl.voltmx.filesystem.getDataDirectory",
    channel_file_createFile: "com.hcl.voltmx.file.createFile",
    channel_file_copyTo: "com.hcl.voltmx.file.copyTo",
    channel_file_createDirectory: "com.hcl.voltmx.file.createDirectory",
    channel_file_fileExists: "com.hcl.voltmx.file.fileExists",
    channel_file_getFileList: "com.hcl.voltmx.file.getFileList",
    channel_file_isDirectory: "com.hcl.voltmx.file.isDirectory",
    channel_file_isFile: "com.hcl.voltmx.file.isFile",
    channel_file_moveTo: "com.hcl.voltmx.file.moveTo",
    channel_file_read: "com.hcl.voltmx.file.read",
    channel_file_readAsText: "com.hcl.voltmx.file.readAsText",
    channel_file_remove: "com.hcl.voltmx.file.remove",
    channel_file_rename: "com.hcl.voltmx.file.rename",
    channel_file_write: "com.hcl.voltmx.file.write",
}