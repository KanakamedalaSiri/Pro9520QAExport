// preloadio.js
console.log("Loading preloadio.js");
const { contextBridge, ipcRenderer } = require("electron");

const ioBootstrap = ipcRenderer.sendSync("com.hcl.voltmx.ioBootstrap");

function handleError(error, channel) { 
  if (error) {
    const msg = error.errorMessage ?? error.message;
    throw new Error(msg ? msg : `An error occurred in channel ${channel ? channel : 'unknown'}`);
  }
}

contextBridge.exposeInMainWorld("voltmxio", {
        io: {
          FileSystem: {
              getDataDirectory: function(){
                  console.log("In getDataDirectory");
                  const channel = ioBootstrap.channel_filesystem_getDataDirectory;
                  const results = ipcRenderer.sendSync(channel);
                  handleError(results?.error, channel);
                  console.log(`getDataDirectory result = ${results.value}`);
                  return results.value;
              }
          },
          File: function(filePath){
            return {
              createFile: function() {
                console.debug("In createFile");
                const channel = ioBootstrap.channel_file_createFile;
                const results = ipcRenderer.sendSync(channel, filePath, '');
                handleError(results?.error, channel);
                return results.value;
              },
              copyTo: function(targetPath, newName) {
                console.debug("In copyTo");
                const channel = ioBootstrap.channel_file_copyTo;
                const results = ipcRenderer.sendSync(channel, filePath, targetPath, newName);
                handleError(results?.error, channel);
                return results.value;
              },
              createDirectory: function() {
                console.debug("In createDirectory");
                const channel = ioBootstrap.channel_file_createDirectory;
                const results = ipcRenderer.sendSync(channel, filePath);
                handleError(results?.error, channel);
                return results.value;
              },
              exists: function() {
                console.debug("In fileExists");
                const channel = ioBootstrap.channel_file_fileExists;
                const results = ipcRenderer.sendSync(channel, filePath);
                handleError(results?.error, channel);
                return results.value;
              },
              getFileList: function() {
                console.debug("In getFileList");
                const channel = ioBootstrap.channel_file_getFileList;
                const results = ipcRenderer.sendSync(channel, filePath);
                handleError(results?.error, channel);
                return results.value;
              },
              isDirectory: function() {
                console.debug("In file isDirectory");
                const channel = ioBootstrap.channel_file_isDirectory;
                const results = ipcRenderer.sendSync(channel, filePath);
                console.log(results);
                // handleError(results?.error, channel);
                if (results?.error) {
                  console.log(results.error);
                  return false;
                }
                return results.value;
              },
              isFile: function() {
                console.debug("In file isFile");
                const channel = ioBootstrap.channel_file_isFile;
                const results = ipcRenderer.sendSync(channel, filePath);
                // handleError(results?.error, channel);
                if (results.error) {
                  console.log(results.error);
                  return false;
                }
                return results.value;
              },
              moveTo: function(targetPath, newName) {
                console.debug("In file moveTo");
                const channel = ioBootstrap.channel_file_moveTo;
                const results = ipcRenderer.sendSync(channel, filePath, targetPath, newName);
                handleError(results?.error, channel);
                return results.value;
              },
              read: function() {
                console.debug("In file read");
                const channel = ioBootstrap.channel_file_read;
                const results = ipcRenderer.sendSync(channel, filePath);
                handleError(results?.error, channel);
                return results.value;
              },
              readAsText: function() {
                console.debug("In file readAsText");
                const channel = ioBootstrap.channel_file_readAsText;
                const results = ipcRenderer.sendSync(channel, filePath);
                handleError(results?.error, channel);
                return results.value;
              },
              remove: function(deleteRecursive) {
                console.debug("In file remove");
                const channel = ioBootstrap.channel_file_remove;
                const results = ipcRenderer.sendSync(channel, filePath, deleteRecursive);
                // handleError(results?.error, channel);
                if (results?.error) {
                  console.log(results.error);
                  return false;
                }
                return results.value;
              },
              rename: function(newName) {
                console.debug("In file rename");
                const channel = ioBootstrap.channel_file_rename;
                const results = ipcRenderer.sendSync(channel, filePath, newName);
                handleError(results?.error, channel);
                return results.value;
              },
              write: function(data, append) {
                console.debug("In file write");
                const channel = ioBootstrap.channel_file_write;
                let writeData = data;
                if (Array.isArray(writeData)) {
                    writeData = Buffer.from(writeData);
                }
                const results = ipcRenderer.sendSync(channel, filePath, data, append);
                handleError(results?.error, channel);
                return results.value;
              }
            }
         }
      }
  });