// preloadform.js
console.log("Loading preloadform.js");
const { contextBridge, ipcRenderer } = require("electron");
const formBootstrap = ipcRenderer.sendSync("com.hcl.voltmx.formBootstrap");
let voltmxCallback;

function handleError(error, channel) { 
  if (error) {
    const msg = error.errorMessage ?? error.message;
    throw new Error(msg ? msg : `An error occurred in channel ${channel ? channel : 'unknown'}`);
  }
}

const fireFormEvent = function(evt) {
    if (voltmxCallback && typeof(voltmxCallback) === 'function') {
      voltmxCallback(evt);
    }
}

contextBridge.exposeInMainWorld("voltmxform", {
      form: {
          setEventCallback: function(aCallback) {
            voltmxCallback = aCallback;
          },
          addFormMaximizedListener: function() {
            ipcRenderer.on(formBootstrap.channel_form_maximized, (evt, menuItem) =>{
                console.log("dispatching onMaximized event");
                fireFormEvent('onMaximized');
            });
          },
          addFormMinimizedListener: function() {
            ipcRenderer.on(formBootstrap.channel_form_minimized, (evt, menuItem) =>{
                console.log("dispatching onMinimized event");
                fireFormEvent('onMinimized');
            });
          },
          addFormRestoredListener: function() {
            ipcRenderer.on(formBootstrap.channel_form_restored, (evt, menuItem) =>{
                console.log("dispatching onRestored event");
                fireFormEvent('onRestored');
            });
          },
          addFormResizedListener: function() {
            ipcRenderer.on(formBootstrap.channel_form_resized, (evt, menuItem) =>{
                console.log("dispatching onResized event");
                fireFormEvent('onResized');
            });
          },
          enableMaximizable: async function(enable) {
              const channel = formBootstrap.channel_form_enableMaximizable;
              console.debug(`In ${formBootstrap.channel_form_enableMaximizable}`);
              const results = await ipcRenderer.invoke(channel, enable);
              handleError(results?.error, channel);
              return results.value;
          },
          enableMinimizable: async function(enable) {
              const channel = formBootstrap.channel_form_enableMinimizable;
              console.debug(`In ${formBootstrap.channel_form_enableMinimizable}`);
              const results = await ipcRenderer.invoke(channel, enable);
              handleError(results?.error, channel);
              return results.value;
          },
          enableRestorable: async function(enable) {
              const channel = formBootstrap.channel_form_enableRestorable;
              console.debug(`In ${formBootstrap.channel_form_enableRestorable}`);
              const results = await ipcRenderer.invoke(channel, enable);
              handleError(results?.error, channel);
              return results.value;
          },
          enableClosable: async function(enable) {
              const channel = formBootstrap.channel_form_enableClosable;
              console.debug(`In ${formBootstrap.channel_form_enableClosable}`);
              const results = await ipcRenderer.invoke(channel, enable);
              handleError(results?.error, channel);
              return results.value;
          },
          setTitle: async function(aTitle) {
              const channel = formBootstrap.channel_form_setTitle;
              console.debug(`In ${channel}`);
              const results = await ipcRenderer.invoke(channel, aTitle);
              handleError(results?.error, channel);
              return results.value;
          }
      }
  });